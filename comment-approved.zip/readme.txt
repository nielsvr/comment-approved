=== Plugin Name ===
Contributors: nielsvanrenselaar
Donate link: 
Tags: comment, approved, notifcation, message, approval
Requires at least: 3.0.0
Tested up to: 3.9.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

This plugin will sent out a customizable notification to a user that has left an comment on your site after approval of the comment.

== Installation ==

1. Upload the folder `comment-approved` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. The settings are accessible trough the settings menu in the sidebar

== Screenshots ==

1. The settings screen

== Changelog ==

= 1.0 =
* Initial release

== Upgrade Notice ==

= 1.0 =
* First version